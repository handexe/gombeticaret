import React from "react";
import { Container, Card } from "react-bootstrap";
const MostLiked = () => {
  return (
    <Container
      className="bg-white"
      style={{ marginTop: "3rem", height: "15rem" }}>
      <Card style={{ height: "10rem" }}></Card>
    </Container>
  );
};

export default MostLiked;
