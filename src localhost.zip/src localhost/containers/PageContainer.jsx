import React from 'react'

const PageContainer = ({children}) => {
  return (
    <div>
      {children}
    </div>
  )
}

export default PageContainer
